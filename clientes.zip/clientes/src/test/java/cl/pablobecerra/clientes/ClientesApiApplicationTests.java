package cl.pablobecerra.clientes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientesApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
